# android_login_php_api

##Using volley library to login MySQL DB, api is build using PHP and method is POST
